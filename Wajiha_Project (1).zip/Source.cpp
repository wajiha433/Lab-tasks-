#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

class WordLadder {
private:
    vector<string> dictionary;  // Holds karta ha 5-letter words
    vector<string> visited;     // visited words ko track krta ha

    bool is_one_diff(const string& word, const string& compare);
    bool is_in_dict(const string& s);
    bool is_visited(const string& s);

public:
    WordLadder(const string& listFile);
    void outputLadder(const string& start, const string& end);
    void clearVisited(); 
};

WordLadder::WordLadder(const string& listFile) {
    ifstream ipfile(listFile);

    if (!ipfile) {
        cout << "Error: Could not open input file.\n";
        exit(1);
    }

    string temp;
    while (ipfile >> temp) {
        if (temp.length() == 5)  // Ensure only 5-letter words loads
            dictionary.push_back(temp);
    }

    ipfile.close();
}

void WordLadder::clearVisited() {
    visited.clear();
}

bool WordLadder::is_one_diff(const string& word, const string& compare) {
    if (word.length() != compare.length())
        return false;

    int diffCount = 0;
    for (size_t i = 0; i < word.length(); ++i) {
        if (word[i] != compare[i])
            diffCount++;
    }
    return diffCount == 1;
}

bool WordLadder::is_in_dict(const string& s) {
    for (const string& word : dictionary) {
        if (word == s)
            return true;
    }
    return false;
}

bool WordLadder::is_visited(const string& s) {
    for (const string& word : visited) {
        if (word == s)
            return true;
    }
    return false;
}

void WordLadder::outputLadder(const string& start, const string& end) {
    if (!is_in_dict(start) || !is_in_dict(end)) {
        cout << "Error: Please enter valid 5-letter words from the dictionary.\n";
        return;
    }

    if (start == end) {
        cout << start << endl;
        cout << "Ladder length: 1" << endl;
        return;
    }

    vector<vector<string>> ladders = { {start} };
    visited.push_back(start);

    while (!ladders.empty()) {
        vector<vector<string>> new_ladders;

        for (const vector<string>& path : ladders) {
            string lastWord = path.back();

            for (const string& word : dictionary) {
                if (is_one_diff(lastWord, word) && !is_visited(word)) {
                    vector<string> newPath = path;
                    newPath.push_back(word);
                    visited.push_back(word);

                    if (word == end) {
                        for (const string& w : newPath) {
                            cout << w << " ";
                        }
                        cout << "\nLadder length: " << newPath.size() << endl;
                        return;
                    }

                    new_ladders.push_back(newPath);
                }
            }
        }

        ladders = new_ladders;
    }

    cout << "No word ladder found from " << start << " to " << end << "." << endl;
}

void clearScreen() {
    system("cls");
}

int main() {
    string start, end;
    int choice;
    WordLadder wordLadder("words5.txt");

    clearScreen();
    cout << "=========================================\n";
    cout << "      WELCOME TO WORD LADDER GAME        \n";
    cout << "=========================================\n";
    cout << "\n\nPress Enter to continue...";
    cin.ignore();

    do {
        clearScreen();
        cout << "========== WORD LADDER MENU ==========\n";
        cout << "1. Run Word Ladder\n";
        cout << "2. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1:
            cout << "\nEnter start word: ";
            cin >> start;
            cout << "Enter end word: ";
            cin >> end;

            wordLadder.clearVisited();
            cout << "\nSearching for ladder...\n\n";
            wordLadder.outputLadder(start, end);

            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            break;

        case 2:
            cout << "Exiting the program...\n";
            break;

        default:
            cout << "Invalid choice. Please try again.\n";
            cout << "Press Enter to continue...";
            cin.ignore();
            cin.get();
        }
    } while (choice != 2);

    return 0;
}
